package gr.aueb.mscis.sample.service;

public class NotifyEpoptes {

}
